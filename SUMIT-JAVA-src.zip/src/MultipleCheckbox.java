import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultipleCheckbox {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "C:\\chromedrv\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.seleniumeasy.com/test/basic-checkbox-demo.html");
        System.out.println("Welcome to automation");
        driver.manage().window().maximize();
        try{
       	 Thread.sleep(5000);
       	 }
       	 catch(InterruptedException ie){
       	 }
        driver.findElement(By.id("check1")).click();
        System.out.println(driver.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[1]/label/input")).isSelected());
        System.out.println(driver.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[2]/label/input")).isSelected());
        System.out.println(driver.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[3]/label/input")).isSelected());
        System.out.println(driver.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[4]/label/input")).isSelected());
        
       String a=driver.findElement(By.id("check1")).getAttribute("Value");
       System.out.println(a);
      driver.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[1]/label/input")).click();
      driver.findElement(By.xpath("//*[@id=\"easycont\"]/div/div[2]/div[2]/div[2]/div[2]/label/input")).click();
       String a1=driver.findElement(By.id("check1")).getAttribute("Value");
       System.out.println(a1);
       driver.quit();
      
      }
 }
	


