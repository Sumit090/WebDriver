package JavaBasic;

public class JavaMethod {
	
	int i=20;//Global Variable 
	static String s="200";//Static variable
    
	
    //Method overloading : Creating same method with different arguments or input parameter within the same class
	//Method overriding : when same method is available in parent and child class with same attribute and same value in different class .
	//static method : Direct calling /or call by class 
	//Non Static method : Call through Object reference after creating object 
	//wrapper class: Converting one data type in to others (String to int =Integer.parseInt() )
	public static void main(String[] args) {
		
		JavaMethod obj=new JavaMethod();
		int k=obj.test();
		int l=Integer.parseInt(s);
		System.out.println(l);
		System.out.println(k);
		obj.test1();
		int z=obj.Test2(5, 6);
		System.out.println(z);
		//System.out.println(obj.s); 
		System.out.println(obj.i);
		test3();             //We can directly call static method 
		JavaMethod.test3();  //We can also call by class name 
		obj.sum();
		obj.sum(5);
		obj.sum(10,15);
	}
	public	int test()  // Non static method with some output
		{
		System.out.println("test method ");
			int i=10;  //Local Variable
			int j=20;
			int k=i+j;
			return k;
			}
	public void test1() {
		System.out.println("Test Method 1");
	}
	
	public int Test2(int j, int k) {
		System.out.println("test method 2");
		int z=j*k;
		return z;
		
	}
	
	public static void test3() {  //Static method 
		System.out.println("Static method ");
	}
	public void sum() {
		
		System.out.println("Sum method ");
	}
	
	public void sum(int q) {
		System.out.println("Method Overloading");
	}
	public void sum(int w,int e) {
		System.out.println("With Two arguments ");
	}
		}

