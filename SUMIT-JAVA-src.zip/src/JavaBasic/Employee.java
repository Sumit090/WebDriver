package JavaBasic;

public class Employee {
  
	String name ;
	String dept;
	int age;
	Employee(String name, String dept, int age){
		this.name=name;
		this.dept=dept;
		this.age=age;
		
	}
	
	
	
	
}
