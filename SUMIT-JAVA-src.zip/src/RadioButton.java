import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButton {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedrv\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
        System.out.println("Welcome to automation");
        driver.manage().window().maximize();
        try{
       	 Thread.sleep(5000);
       	 }
       	 catch(InterruptedException ie){
       	 }
        //driver.findElement(By.name("optradio")).click();
        driver.findElement(By.id("buttoncheck")).click();
        String s =driver.findElement(By.xpath("//p[@class='radiobutton']")).getText();
        System.out.println(s);
        
        driver.quit();
	}

}
