import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Exercise1 {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "C:\\chromedrv\\chromedriver.exe");
         WebDriver driver = new ChromeDriver();
         driver.get("https://www.seleniumeasy.com/test/basic-first-form-demo.html");
         System.out.println("Welcome to automation");
         driver.manage().window().maximize();
         try{
        	 Thread.sleep(5000);
        	 }
        	 catch(InterruptedException ie){
        	 }
         driver.findElement(By.xpath("//input[@id=\"user-message\"]")).sendKeys("Welcome");
         driver.findElement(By.xpath("//*[@id=\"get-input\"]/button")).click();
         String  a =driver.findElement(By.xpath("//span[@id='display']")).getText();
         System.out.println(a);
         
         if (a.contains("Welcome java"))
         {
        	 System.out.println("True");
         }
         else{
        	 System.out.println("False");
         }
         driver.close();


	}

}
