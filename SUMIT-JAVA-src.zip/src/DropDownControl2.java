import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DropDownControl2 {

	public static void main(String[] args) throws AWTException {
	System.setProperty("webdriver.chrome.driver", "C:\\chromedrv\\\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.seleniumeasy.com/test/basic-select-dropdown-demo.html");
	driver.manage().window().maximize();
	  try{
	       	 Thread.sleep(5000);
	       	 }
	       	 catch(InterruptedException ie){
	       	 }
	  //driver.findElement(By.xpath("//select[@id='multi-select']/option[@value='New Jersey']")).click();
	  //driver.findElement(By.xpath("//button[@id='printMe']")).click();
	  //String a =driver.findElement(By.xpath("//p[@class='getall-selected']")).getText();
	  //System.out.println(a);
	  
	  Robot robot=new Robot();
	  robot.keyPress(KeyEvent.VK_CONTROL);
	  driver.findElement(By.xpath("//select[@id='multi-select']/option[@value='New Jersey']")).click();
	  
	  driver.findElement(By.xpath("//select[@id='multi-select']/option[@value='New York']")).click();
	 
	  driver.findElement(By.xpath("//select[@id='multi-select']/option[@value='Ohio']")).click();
	  robot.keyRelease(KeyEvent.VK_CONTROL);
	  driver.findElement(By.xpath("//button[@id='printAll']")).click();
	  String a1=driver.findElement(By.xpath("//p[@class='getall-selected']")).getText();
	  System.out.println(a1);
	  
	  //Unable to select all value need to check 
	  
}
	
}
