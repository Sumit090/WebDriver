import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DropDownControl1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\chromedrv\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.seleniumeasy.com/test/basic-select-dropdown-demo.html");
        System.out.println("Welcome to automation");
        driver.manage().window().maximize();
        try{
       	 Thread.sleep(5000);
       	 }
       	 catch(InterruptedException ie){
       	 }
		driver.findElement(By.xpath("//select[@id='select-demo' ]/option[@value='Tuesday' and .='Tuesday']")).click();
		String a=driver.findElement(By.xpath("//p[@class='selected-value']")).getText();
		System.out.println(a);
		}

}
