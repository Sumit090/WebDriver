import java.awt.AWTException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TextFileImport {

	public static void main(String[] args) {

	    System.setProperty("webdriver.chrome.driver", "C:\\chromedrv\\\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.seleniumeasy.com/test/input-form-demo.html");
		driver.manage().window().maximize();
		  try{
		       	 Thread.sleep(5000);
		       	 }
		       	 catch(InterruptedException ie){
		       	 }	
		  BufferedReader br=null;
		  try {
			  String sCurrentLine;
			  
			  System.out.println("a");
			  br=new BufferedReader(new FileReader("C:\\Users\\753778\\Desktop"));
			  
			  while ((sCurrentLine = br.readLine()) != null) {
				  System.out.println(sCurrentLine);
			  }
		  }
		catch  (IOException e) {
			e.printStackTrace();
		}
		  finally {
			  try {
				  if (br != null)br.close();
			  } catch (IOException ex) {
	                ex.printStackTrace();
			  }
		}
		  
		  
		  
	}

}
